import 'package:flutter/material.dart';

class Alpha {
  late Color c;
  late String alpha;
}

List<Alpha> colorsList = [
  Alpha()
    ..c = Colors.blue
    ..alpha = 'A',
  Alpha()
    ..c = Colors.red
    ..alpha = 'B',
  Alpha()
    ..c = Colors.green
    ..alpha = 'C',
  Alpha()
    ..c = Colors.orange
    ..alpha = 'D',
  Alpha()
    ..c = Colors.pink
    ..alpha = 'E',
  Alpha()
    ..c = Colors.yellow
    ..alpha = 'F',
  Alpha()
    ..c = Colors.purple
    ..alpha = 'G',
  Alpha()
    ..c = Colors.pink
    ..alpha = 'H',
  Alpha()
    ..c = Colors.blue
    ..alpha = 'I',
  Alpha()
    ..c = Colors.red
    ..alpha = 'J',
  Alpha()
    ..c = Colors.green
    ..alpha = 'K',
  Alpha()
    ..c = Colors.yellow
    ..alpha = 'L',
  Alpha()
    ..c = Colors.purple
    ..alpha = 'M',
  Alpha()
    ..c = Colors.pink
    ..alpha = 'N',
  Alpha()
    ..c = Colors.blue
    ..alpha = 'O',
  Alpha()
    ..c = Colors.red
    ..alpha = 'P',
  Alpha()
    ..c = Colors.green
    ..alpha = 'Q',
  Alpha()
    ..c = Colors.yellow
    ..alpha = 'R',
  Alpha()
    ..c = Colors.purple
    ..alpha = 'S',
  Alpha()
    ..c = Colors.orange
    ..alpha = 'T',
  Alpha()
    ..c = Colors.pink
    ..alpha = 'U',
  Alpha()
    ..c = Colors.blue
    ..alpha = 'V',
  Alpha()
    ..c = Colors.green
    ..alpha = 'W',
  Alpha()
    ..c = Colors.red
    ..alpha = 'X',
  Alpha()
    ..c = Colors.yellow
    ..alpha = 'Y',
  Alpha()
    ..c = Colors.purple
    ..alpha = 'Z',
];
